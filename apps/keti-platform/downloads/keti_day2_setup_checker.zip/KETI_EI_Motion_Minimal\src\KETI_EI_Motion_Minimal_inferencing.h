/* Minimal local Arduino wrapper for Edge Impulse C++ library export. */
#ifndef KETI_EI_MOTION_MINIMAL_INFERENCING_H
#define KETI_EI_MOTION_MINIMAL_INFERENCING_H

#define EIDSP_USE_CMSIS_DSP 0
#define EIDSP_LOAD_CMSIS_DSP_SOURCES 0
#define EI_CLASSIFIER_TFLITE_ENABLE_CMSIS_NN 0
#define EI_CLASSIFIER_TFLITE_LOAD_CMSIS_NN_SOURCES 0

#include <Arduino.h>
#include <stdarg.h>

#ifdef min
#undef min
#endif
#ifdef max
#undef max
#endif
#ifdef round
#undef round
#endif
#ifdef DEFAULT
#undef DEFAULT
#endif
#ifdef A0
#undef A0
#endif
#ifdef A1
#undef A1
#endif
#ifdef A2
#undef A2
#endif

#include "edge-impulse-sdk/classifier/ei_run_classifier.h"
#include "edge-impulse-sdk/dsp/numpy.hpp"
#include "model-parameters/model_metadata.h"
#include "edge-impulse-sdk/classifier/ei_classifier_smooth.h"

extern void ei_printf(const char *format, ...);

#endif
