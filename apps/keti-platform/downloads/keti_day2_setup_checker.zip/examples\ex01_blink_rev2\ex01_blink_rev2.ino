/*
  Day 2 Example 01: Blink
  Board: Arduino Nano 33 BLE Rev2
*/

const uint8_t LED_PIN = LED_BUILTIN;

void setup() {
  pinMode(LED_PIN, OUTPUT);
}

void loop() {
  digitalWrite(LED_PIN, HIGH);
  delay(500);

  digitalWrite(LED_PIN, LOW);
  delay(500);
}
