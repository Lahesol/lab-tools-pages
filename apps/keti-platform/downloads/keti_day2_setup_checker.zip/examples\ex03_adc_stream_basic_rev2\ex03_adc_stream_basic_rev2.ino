/*
  Day 2 Example 03: Basic ADC streaming
  Board: Arduino Nano 33 BLE Rev2

  Connect the signal to A0 and keep it in the 0.0 V to 3.3 V range.

  Serial output:
    <raw_adc_code>

*/

const uint32_t SERIAL_BAUD = 115200;
const uint8_t ADC_PIN = A0;
const uint8_t ADC_BITS = 12;
const uint32_t SAMPLE_RATE_HZ = 100;
const uint32_t SAMPLE_INTERVAL_US = 1000000UL / SAMPLE_RATE_HZ;

uint32_t nextSampleUs = 0;

void setup() {
  Serial.begin(SERIAL_BAUD);
  analogReadResolution(ADC_BITS);
  nextSampleUs = micros();
}

void loop() {
  const uint32_t nowUs = micros();
  if ((int32_t)(nowUs - nextSampleUs) < 0) {
    return;
  }
  nextSampleUs += SAMPLE_INTERVAL_US;

  const int raw = analogRead(ADC_PIN);
  Serial.println(raw);
}
