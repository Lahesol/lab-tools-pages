/*
  Day 2 Example 03: Basic ADC streaming
  Board: Arduino Nano 33 BLE Rev2

  Connect the signal to A0 and keep it in the 0.0 V to 3.3 V range.

  Serial output:
    <raw_adc_code>

  Serial command:
    RATE <1-1000>
    CH <0-7>
    RES <10|12>
*/

#include <ctype.h>
#include <stdlib.h>
#include <string.h>

const uint32_t SERIAL_BAUD = 115200;
const uint8_t ADC_PINS[] = { A0, A1, A2, A3, A4, A5, A6, A7 };
const uint8_t ADC_CHANNEL_COUNT = sizeof(ADC_PINS) / sizeof(ADC_PINS[0]);
const uint8_t DEFAULT_ADC_CHANNEL = 0;
const uint8_t DEFAULT_ADC_BITS = 12;
const float DEFAULT_SAMPLE_RATE_HZ = 100.0f;
const uint8_t COMMAND_BUFFER_SIZE = 32;

float sampleRateHz = DEFAULT_SAMPLE_RATE_HZ;
uint32_t sampleIntervalUs = 1000000UL / (uint32_t)DEFAULT_SAMPLE_RATE_HZ;
uint8_t adcChannel = DEFAULT_ADC_CHANNEL;
uint8_t adcBits = DEFAULT_ADC_BITS;
uint32_t nextSampleUs = 0;
char commandBuffer[COMMAND_BUFFER_SIZE];
uint8_t commandLength = 0;

void setSampleRate(float rateHz) {
  if (rateHz < 1.0f) {
    rateHz = 1.0f;
  }
  if (rateHz > 1000.0f) {
    rateHz = 1000.0f;
  }

  sampleRateHz = rateHz;
  sampleIntervalUs = (uint32_t)((1000000.0f / sampleRateHz) + 0.5f);
  if (sampleIntervalUs < 1) {
    sampleIntervalUs = 1;
  }
  nextSampleUs = micros();

  Serial.print("ACK,RATE,rate_hz=");
  Serial.println(sampleRateHz, 2);
}

void setAdcChannel(long channel) {
  if (channel < 0 || channel >= ADC_CHANNEL_COUNT) {
    Serial.println("ERR,CH requires 0-7");
    return;
  }

  adcChannel = (uint8_t)channel;
  nextSampleUs = micros();

  Serial.print("ACK,CH,channel=");
  Serial.println(adcChannel);
}

void setAdcResolutionBits(long bits) {
  if (bits != 10 && bits != 12) {
    Serial.println("ERR,RES requires 10 or 12");
    return;
  }

  adcBits = (uint8_t)bits;
  analogReadResolution(adcBits);
  nextSampleUs = micros();

  Serial.print("ACK,RES,bits=");
  Serial.println(adcBits);
}

void handleCommand(char *line) {
  while (*line == ' ' || *line == '\t') {
    line++;
  }

  char *command = strtok(line, " \t,");
  char *arg = strtok(NULL, " \t,");
  if (command == NULL) {
    return;
  }

  for (char *p = command; *p != '\0'; p++) {
    *p = (char)toupper(*p);
  }

  if (strcmp(command, "RATE") == 0) {
    if (arg == NULL) {
      Serial.println("ERR,RATE requires Hz");
      return;
    }
    setSampleRate(atof(arg));
  } else if (strcmp(command, "CH") == 0) {
    if (arg == NULL) {
      Serial.println("ERR,CH requires 0-7");
      return;
    }
    setAdcChannel(atol(arg));
  } else if (strcmp(command, "RES") == 0) {
    if (arg == NULL) {
      Serial.println("ERR,RES requires 10 or 12");
      return;
    }
    setAdcResolutionBits(atol(arg));
  }
}

void pollSerialCommands() {
  while (Serial.available() > 0) {
    const char c = (char)Serial.read();
    if (c == '\r') {
      continue;
    }
    if (c == '\n') {
      commandBuffer[commandLength] = '\0';
      handleCommand(commandBuffer);
      commandLength = 0;
      continue;
    }
    if (commandLength < COMMAND_BUFFER_SIZE - 1) {
      commandBuffer[commandLength++] = c;
    } else {
      commandLength = 0;
      Serial.println("ERR,Command too long");
    }
  }
}

void setup() {
  Serial.begin(SERIAL_BAUD);
  analogReadResolution(adcBits);
  nextSampleUs = micros();
}

void loop() {
  pollSerialCommands();

  const uint32_t nowUs = micros();
  if ((int32_t)(nowUs - nextSampleUs) < 0) {
    return;
  }
  nextSampleUs += sampleIntervalUs;

  const int raw = analogRead(ADC_PINS[adcChannel]);
  Serial.println(raw);
}
