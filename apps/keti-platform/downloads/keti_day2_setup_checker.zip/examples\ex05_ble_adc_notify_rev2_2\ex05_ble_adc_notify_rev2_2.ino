/*
  Day 2 Example 04: ADC over BLE notification
  Board: Arduino Nano 33 BLE Rev2

  Requires ArduinoBLE.

  BLE device name:
    KETI_ADC_REV2

  Characteristic payload:
    <millis>,<raw_adc>
*/

#include <ArduinoBLE.h>
#include <stdio.h>
#include <string.h>

const uint32_t SERIAL_BAUD = 115200;
const uint8_t ADC_PIN = A0;
const uint8_t ADC_BITS = 12;
const uint32_t SAMPLE_RATE_HZ = 32;
const uint32_t SAMPLE_INTERVAL_MS = 1000UL / SAMPLE_RATE_HZ;

BLEService adcService("19B10000-E8F2-537E-4F6C-D104768A1214");
BLECharacteristic adcCharacteristic(
    "19B10001-E8F2-537E-4F6C-D104768A1214",
    BLERead | BLENotify,
    32);

uint32_t lastSampleMs = 0;

void setup() {
  Serial.begin(SERIAL_BAUD);
  analogReadResolution(ADC_BITS);
  pinMode(LED_BUILTIN, OUTPUT);

  if (!BLE.begin()) {
    Serial.println("ERR,BLE begin failed");
    while (true) {
      digitalWrite(LED_BUILTIN, HIGH);
      delay(100);
      digitalWrite(LED_BUILTIN, LOW);
      delay(100);
    }
  }

  BLE.setLocalName("KETI_ADC_REV2");
  BLE.setDeviceName("KETI_ADC_REV2");
  BLE.setAdvertisedService(adcService);

  adcService.addCharacteristic(adcCharacteristic);
  BLE.addService(adcService);

  adcCharacteristic.writeValue((const uint8_t *)"0,0", 3);
  BLE.advertise();

  Serial.println("READY,KETI_ADC_REV2,service=19B10000-E8F2-537E-4F6C-D104768A1214");
}

void loop() {
  BLEDevice central = BLE.central();
  if (!central) {
    digitalWrite(LED_BUILTIN, LOW);
    return;
  }

  digitalWrite(LED_BUILTIN, HIGH);
  Serial.print("CONNECTED,");
  Serial.println(central.address());

  while (central.connected()) {
    BLE.poll();

    const uint32_t nowMs = millis();
    if (nowMs - lastSampleMs < SAMPLE_INTERVAL_MS) {
      continue;
    }
    lastSampleMs = nowMs;

    const int raw = analogRead(ADC_PIN);
    char payload[32];
    const int length = snprintf(payload, sizeof(payload), "%lu,%d",
                                (unsigned long)nowMs, raw);

    if (length > 0 && length < (int)sizeof(payload)) {
      adcCharacteristic.writeValue((const uint8_t *)payload, length);
      Serial.print("BLE_DATA,");
      Serial.println(payload);
    }
  }

  digitalWrite(LED_BUILTIN, LOW);
  Serial.println("DISCONNECTED");
}
