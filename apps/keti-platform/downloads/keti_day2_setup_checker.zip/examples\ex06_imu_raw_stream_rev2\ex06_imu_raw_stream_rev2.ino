/*
  Day 2 Example 05: IMU raw stream
  Board: Arduino Nano 33 BLE Rev2

  Requires Arduino_BMI270_BMM150.

  Serial output:
    IMU,<seq>,<micros>,<ax_g>,<ay_g>,<az_g>,<gx_dps>,<gy_dps>,<gz_dps>,<mx_uT>,<my_uT>,<mz_uT>
*/

#include <Arduino_BMI270_BMM150.h>

const uint32_t SERIAL_BAUD = 115200;
const uint32_t IMU_RATE_HZ = 50;
const uint32_t IMU_INTERVAL_US = 1000000UL / IMU_RATE_HZ;

uint32_t nextImuUs = 0;
uint32_t sequence = 0;

float ax = 0.0f;
float ay = 0.0f;
float az = 0.0f;
float gx = 0.0f;
float gy = 0.0f;
float gz = 0.0f;
float mx = 0.0f;
float my = 0.0f;
float mz = 0.0f;

void setup() {
  Serial.begin(SERIAL_BAUD);
  pinMode(LED_BUILTIN, OUTPUT);

  if (!IMU.begin()) {
    Serial.println("ERR,IMU begin failed");
    while (true) {
      digitalWrite(LED_BUILTIN, HIGH);
      delay(100);
      digitalWrite(LED_BUILTIN, LOW);
      delay(100);
    }
  }

  IMU.setContinuousMode();
  nextImuUs = micros();
  Serial.println("READY,IMU_RAW_REV2");
}

void loop() {
  while (IMU.accelerationAvailable()) {
    IMU.readAcceleration(ax, ay, az);
  }
  while (IMU.gyroscopeAvailable()) {
    IMU.readGyroscope(gx, gy, gz);
  }
  if (IMU.magneticFieldAvailable()) {
    IMU.readMagneticField(mx, my, mz);
  }

  const uint32_t nowUs = micros();
  if ((int32_t)(nowUs - nextImuUs) < 0) {
    return;
  }
  nextImuUs += IMU_INTERVAL_US;

  Serial.print("IMU,");
  Serial.print(sequence++);
  Serial.print(",");
  Serial.print(nowUs);
  Serial.print(",");
  Serial.print(ax, 6);
  Serial.print(",");
  Serial.print(ay, 6);
  Serial.print(",");
  Serial.print(az, 6);
  Serial.print(",");
  Serial.print(gx, 6);
  Serial.print(",");
  Serial.print(gy, 6);
  Serial.print(",");
  Serial.print(gz, 6);
  Serial.print(",");
  Serial.print(mx, 6);
  Serial.print(",");
  Serial.print(my, 6);
  Serial.print(",");
  Serial.println(mz, 6);
}
