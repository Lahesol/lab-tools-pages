/*
  Day 2 Example 07: IMU Motion Classification
  Target: Arduino Nano 33 BLE Rev2
  Source equivalent: firmware/stage2_imu_ei_motion/stage2_imu_ei_motion.ino

  Serial protocol:
    IMU,<seq>,<micros>,<ax_g>,<ay_g>,<az_g>,<gx_dps>,<gy_dps>,<gz_dps>,<mx_uT>,<my_uT>,<mz_uT>
    CLS,<seq>,<millis>,<top_label>,<top_score>,dsp_ms=<n>,classification_ms=<n>,anomaly_ms=<n>,scores=<label>:<score>|...
*/

#include <Arduino.h>
#include <Arduino_BMI270_BMM150.h>

// Edge Impulse C++ export is wrapped as a local Arduino library under
// firmware/libraries/KETI_EI_Motion_Minimal.
#define KETI_ENABLE_EDGE_IMPULSE 1

#if KETI_ENABLE_EDGE_IMPULSE
#include <KETI_EI_Motion_Minimal_inferencing.h>
#endif

#define FW_NAME "KETI_STAGE2_IMU_EI_MOTION"
#define FW_VERSION "0.3.0"

static const uint32_t SERIAL_BAUD = 115200;
static const uint16_t COMMAND_BUFFER_SIZE = 96;
static const uint16_t DEFAULT_IMU_RATE_HZ = 63;
static const uint16_t MAX_IMU_RATE_HZ = 500;
static const float CONVERT_G_TO_MS2 = 9.80665f;
static const float MAX_ACCEPTED_RANGE_G = 2.0f;

#if KETI_ENABLE_EDGE_IMPULSE && defined(EI_CLASSIFIER_SENSOR) && \
    EI_CLASSIFIER_SENSOR == EI_CLASSIFIER_SENSOR_ACCELEROMETER && \
    EI_CLASSIFIER_RAW_SAMPLES_PER_FRAME == 3
#define KETI_EI_ACCEL_MODEL 1
#else
#define KETI_EI_ACCEL_MODEL 0
#endif

struct RuntimeConfig {
  uint16_t imuRateHz;
  bool streaming;
  bool classification;
};

struct ImuSample {
  float ax;
  float ay;
  float az;
  float gx;
  float gy;
  float gz;
  float mx;
  float my;
  float mz;
  bool accelValid;
  bool gyroValid;
  bool magValid;
};

RuntimeConfig config = {
  DEFAULT_IMU_RATE_HZ,
  false,
  false
};

char commandBuffer[COMMAND_BUFFER_SIZE];
uint16_t commandLength = 0;

uint32_t imuSequence = 0;
uint32_t classSequence = 0;
uint32_t nextImuMicros = 0;
uint32_t imuIntervalMicros = 1000000UL / DEFAULT_IMU_RATE_HZ;
uint32_t nextClassifierMicros = 0;

ImuSample latestImu = {0};

#if KETI_EI_ACCEL_MODEL
static bool debug_nn = false;
static float classifierBuffer[EI_CLASSIFIER_DSP_INPUT_FRAME_SIZE];
static size_t classifierIndex = 0;
#endif

void updateImuInterval() {
  if (config.imuRateHz < 1) {
    config.imuRateHz = 1;
  }
  if (config.imuRateHz > MAX_IMU_RATE_HZ) {
    config.imuRateHz = MAX_IMU_RATE_HZ;
  }
  imuIntervalMicros = 1000000UL / config.imuRateHz;
}

void printAck(const char *message) {
  Serial.print("ACK,");
  Serial.println(message);
}

void printError(const char *message) {
  Serial.print("ERR,");
  Serial.println(message);
}

void printInfo() {
  Serial.print("INFO,");
  Serial.print(FW_NAME);
  Serial.print(",version=");
  Serial.print(FW_VERSION);
  Serial.print(",board=Arduino Nano 33 BLE Rev2");
  Serial.print(",baud=");
  Serial.print(SERIAL_BAUD);
  Serial.print(",imu=Arduino_BMI270_BMM150");
  Serial.print(",accel_unit=g,gyro_unit=dps,mag_unit=uT");
  Serial.print(",edge_impulse=");
  Serial.print(KETI_EI_ACCEL_MODEL ? "1" : "0");
#if KETI_ENABLE_EDGE_IMPULSE
  Serial.print(",ei_project=");
  Serial.print(EI_CLASSIFIER_PROJECT_NAME);
  Serial.print(",ei_sensor=");
  Serial.print(EI_CLASSIFIER_SENSOR);
  Serial.print(",ei_frame=");
  Serial.print(EI_CLASSIFIER_RAW_SAMPLES_PER_FRAME);
  Serial.print(",ei_interval_ms=");
  Serial.print(EI_CLASSIFIER_INTERVAL_MS);
#else
  Serial.print(",ei_project=not_compiled");
#endif
  Serial.println();
}

void printStatus() {
  Serial.print("STATUS,streaming=");
  Serial.print(config.streaming ? "1" : "0");
  Serial.print(",rate_hz=");
  Serial.print(config.imuRateHz);
  Serial.print(",classification=");
  Serial.print(config.classification ? "1" : "0");
  Serial.print(",edge_impulse=");
  Serial.print(KETI_EI_ACCEL_MODEL ? "1" : "0");
#if KETI_ENABLE_EDGE_IMPULSE
  Serial.print(",ei_label_count=");
  Serial.print(EI_CLASSIFIER_LABEL_COUNT);
  Serial.print(",ei_input_frame=");
  Serial.print(EI_CLASSIFIER_DSP_INPUT_FRAME_SIZE);
#endif
  Serial.println();
}

void printHelp() {
  Serial.println("HELP,PING,STATUS,START,STOP,RATE <1-500>,CLS <ON|OFF>");
}

void uppercase(char *text) {
  for (uint16_t i = 0; text[i] != '\0'; i++) {
    if (text[i] >= 'a' && text[i] <= 'z') {
      text[i] = text[i] - ('a' - 'A');
    }
  }
}

float clampAcceleration(float value) {
  if (fabs(value) <= MAX_ACCEPTED_RANGE_G) {
    return value;
  }
  return value >= 0.0f ? MAX_ACCEPTED_RANGE_G : -MAX_ACCEPTED_RANGE_G;
}

void readLatestImu() {
  float x;
  float y;
  float z;

  while (IMU.accelerationAvailable()) {
    if (IMU.readAcceleration(x, y, z)) {
      latestImu.ax = x;
      latestImu.ay = y;
      latestImu.az = z;
      latestImu.accelValid = true;
    } else {
      break;
    }
  }

  while (IMU.gyroscopeAvailable()) {
    if (IMU.readGyroscope(x, y, z)) {
      latestImu.gx = x;
      latestImu.gy = y;
      latestImu.gz = z;
      latestImu.gyroValid = true;
    } else {
      break;
    }
  }

  if (IMU.magneticFieldAvailable()) {
    if (IMU.readMagneticField(x, y, z)) {
      latestImu.mx = x;
      latestImu.my = y;
      latestImu.mz = z;
      latestImu.magValid = true;
    }
  }
}

void sendImuSample() {
  Serial.print("IMU,");
  Serial.print(imuSequence++);
  Serial.print(',');
  Serial.print(micros());
  Serial.print(',');
  Serial.print(latestImu.ax, 5);
  Serial.print(',');
  Serial.print(latestImu.ay, 5);
  Serial.print(',');
  Serial.print(latestImu.az, 5);
  Serial.print(',');
  Serial.print(latestImu.gx, 3);
  Serial.print(',');
  Serial.print(latestImu.gy, 3);
  Serial.print(',');
  Serial.print(latestImu.gz, 3);
  Serial.print(',');
  Serial.print(latestImu.mx, 3);
  Serial.print(',');
  Serial.print(latestImu.my, 3);
  Serial.print(',');
  Serial.println(latestImu.mz, 3);
}

#if KETI_EI_ACCEL_MODEL
void resetClassifierBuffer() {
  classifierIndex = 0;
  nextClassifierMicros = micros();
}

void runEdgeImpulseClassifier() {
  signal_t signal;
  int err = numpy::signal_from_buffer(classifierBuffer, EI_CLASSIFIER_DSP_INPUT_FRAME_SIZE, &signal);
  if (err != 0) {
    printError("EI_SIGNAL_FROM_BUFFER");
    resetClassifierBuffer();
    return;
  }

  ei_impulse_result_t result = {0};
  err = run_classifier(&signal, &result, debug_nn);
  if (err != EI_IMPULSE_OK) {
    printError("EI_RUN_CLASSIFIER");
    resetClassifierBuffer();
    return;
  }

  size_t topIndex = 0;
  float topValue = 0.0f;
  for (size_t i = 0; i < EI_CLASSIFIER_LABEL_COUNT; i++) {
    if (result.classification[i].value > topValue) {
      topValue = result.classification[i].value;
      topIndex = i;
    }
  }

  Serial.print("CLS,");
  Serial.print(classSequence++);
  Serial.print(',');
  Serial.print(millis());
  Serial.print(',');
  Serial.print(result.classification[topIndex].label);
  Serial.print(',');
  Serial.print(topValue, 5);
  Serial.print(",dsp_ms=");
  Serial.print(result.timing.dsp);
  Serial.print(",classification_ms=");
  Serial.print(result.timing.classification);
  Serial.print(",anomaly_ms=");
  Serial.print(result.timing.anomaly);
  Serial.print(",scores=");
  for (size_t i = 0; i < EI_CLASSIFIER_LABEL_COUNT; i++) {
    if (i > 0) {
      Serial.print('|');
    }
    Serial.print(result.classification[i].label);
    Serial.print(':');
    Serial.print(result.classification[i].value, 5);
  }
#if EI_CLASSIFIER_HAS_ANOMALY == 1
  Serial.print(",anomaly=");
  Serial.print(result.anomaly, 5);
#endif
  Serial.println();

  resetClassifierBuffer();
}

void pollClassifier() {
  if (!config.classification) {
    return;
  }

  const uint32_t now = micros();
  if ((int32_t)(now - nextClassifierMicros) < 0) {
    return;
  }

  readLatestImu();

  classifierBuffer[classifierIndex++] = clampAcceleration(latestImu.ax) * CONVERT_G_TO_MS2;
  classifierBuffer[classifierIndex++] = clampAcceleration(latestImu.ay) * CONVERT_G_TO_MS2;
  classifierBuffer[classifierIndex++] = clampAcceleration(latestImu.az) * CONVERT_G_TO_MS2;

  nextClassifierMicros += ((uint32_t)EI_CLASSIFIER_INTERVAL_MS * 1000UL);
  if ((int32_t)(micros() - nextClassifierMicros) >= 0) {
    nextClassifierMicros = micros() + ((uint32_t)EI_CLASSIFIER_INTERVAL_MS * 1000UL);
  }

  if (classifierIndex >= EI_CLASSIFIER_DSP_INPUT_FRAME_SIZE) {
    runEdgeImpulseClassifier();
  }
}
#else
void resetClassifierBuffer() {}
void pollClassifier() {}
#endif

void handleCommand(char *line) {
  while (*line == ' ' || *line == '\t') {
    line++;
  }
  if (*line == '\0') {
    return;
  }

  uppercase(line);

  char *command = strtok(line, " \t,");
  char *arg = strtok(NULL, " \t,");

  if (command == NULL) {
    return;
  }

  if (strcmp(command, "PING") == 0) {
    printInfo();
    return;
  }

  if (strcmp(command, "HELP") == 0) {
    printHelp();
    return;
  }

  if (strcmp(command, "STATUS") == 0) {
    printStatus();
    return;
  }

  if (strcmp(command, "START") == 0) {
    config.streaming = true;
    nextImuMicros = micros();
    printAck("START");
    return;
  }

  if (strcmp(command, "STOP") == 0) {
    config.streaming = false;
    printAck("STOP");
    return;
  }

  if (strcmp(command, "RATE") == 0) {
    if (arg == NULL) {
      printError("RATE requires Hz");
      return;
    }
    long rate = atol(arg);
    if (rate < 1) {
      rate = 1;
    }
    if (rate > MAX_IMU_RATE_HZ) {
      rate = MAX_IMU_RATE_HZ;
    }
    config.imuRateHz = (uint16_t)rate;
    updateImuInterval();
    printAck("RATE");
    printStatus();
    return;
  }

  if (strcmp(command, "CLS") == 0) {
    if (arg == NULL) {
      printError("CLS requires ON or OFF");
      return;
    }
    if (strcmp(arg, "ON") == 0 || strcmp(arg, "START") == 0) {
#if KETI_EI_ACCEL_MODEL
      config.classification = true;
      resetClassifierBuffer();
      printAck("CLS_ON");
#else
      config.classification = false;
      printError("EI_ACCEL_MODEL_REQUIRED");
#endif
      printStatus();
      return;
    }
    if (strcmp(arg, "OFF") == 0 || strcmp(arg, "STOP") == 0) {
      config.classification = false;
      resetClassifierBuffer();
      printAck("CLS_OFF");
      printStatus();
      return;
    }
    printError("CLS requires ON or OFF");
    return;
  }

  printError("Unknown command");
}

void pollSerial() {
  while (Serial.available() > 0) {
    char c = (char)Serial.read();

    if (c == '\r') {
      continue;
    }

    if (c == '\n') {
      commandBuffer[commandLength] = '\0';
      handleCommand(commandBuffer);
      commandLength = 0;
      return;
    }

    if (commandLength < COMMAND_BUFFER_SIZE - 1) {
      commandBuffer[commandLength++] = c;
    } else {
      commandLength = 0;
      printError("Command too long");
    }
  }
}

void setup() {
  Serial.begin(SERIAL_BAUD);
  delay(250);

  if (!IMU.begin()) {
    Serial.print("READY,");
    Serial.print(FW_NAME);
    Serial.print(",version=");
    Serial.print(FW_VERSION);
    Serial.println(",imu=failed");
    return;
  }

  IMU.setContinuousMode();
  updateImuInterval();
  nextImuMicros = micros();
  nextClassifierMicros = micros();

  Serial.print("READY,");
  Serial.print(FW_NAME);
  Serial.print(",version=");
  Serial.print(FW_VERSION);
  Serial.print(",imu=ok");
  Serial.print(",edge_impulse=");
  Serial.println(KETI_EI_ACCEL_MODEL ? "1" : "0");
}

void loop() {
  pollSerial();
  readLatestImu();
  pollClassifier();

  if (!config.streaming) {
    return;
  }

  const uint32_t now = micros();
  if ((int32_t)(now - nextImuMicros) >= 0) {
    sendImuSample();
    nextImuMicros += imuIntervalMicros;

    if ((int32_t)(micros() - nextImuMicros) >= 0) {
      nextImuMicros = micros() + imuIntervalMicros;
    }
  }
}
